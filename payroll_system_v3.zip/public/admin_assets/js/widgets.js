$(function() {
  'use strict';
  $('#datepickerwidget').datetimepicker({
      inline: true,
      format: 'L'
  });
});