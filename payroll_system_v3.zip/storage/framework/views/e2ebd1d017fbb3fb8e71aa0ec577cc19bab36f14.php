<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title><?php echo e($error); ?> | ApiDocs</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:300,400,600,700,800" rel="stylesheet">
    <style>
        *, body {
            -webkit-font-smoothing: antialiased;
            text-rendering: optimizeLegibility;
            -moz-osx-font-smoothing: grayscale;
        }
        * {
            line-height: 1.2;
            margin: 0;
        }

        html {
            color: #888;
            display: table;
            font-family: 'Nunito Sans', sans-serif;
            height: 100%;
            text-align: center;
            width: 100%;
        }

        .h1, .h2, .h3, .h4, .h5, .h6, h1, h2, h3, h4, h5, h6 {
            font-family: 'Nunito Sans', sans-serif;
        }

        body {
            display: table-cell;
            vertical-align: middle;
            margin: 2em auto;
        }

        h1 {
            color: #ef4153;
            text-shadow: rgba(235, 82, 93, 0.3) 5px 1px, rgba(235, 82, 93, 0.2) 10px 3px;
            font-size: 150px;
            font-weight: 800;
            margin-bottom: 10px;
            letter-spacing: 2px;
        }
        h4 {
            color: #4a5361;
            text-transform: capitalize;
            font-size: 28px;
        }

        p {
            margin: 0 auto;
            max-width: 790px;
            margin-top: 20px;
            color: #666 ;
            margin-bottom: 10px;
            font-size: 15px;
            line-height: 20px;
        }
        a {
            display: inline-block;
            padding: 8px 15px;
            background-color: #ef4153;
            color: #fff;
            text-decoration: none;
            border-radius: 4px;
            margin-top: 20px;
        }

        @media  only screen and (max-width: 280px) {

            body, p {
                width: 95%;
            }

            h1 {
                font-size: 1.5em;
                margin: 0 0 0.3em;
            }

        }

    </style>
</head>
<body>  
    <h1><?php echo e($error_code); ?></h1>
    <h4><?php echo e($error); ?></h4>
    <p>It's looking like you may have taken a wrong turn. Don't worry... it happens to the best of us. Here's a little tip that might help you get back on track.</p>
    <a href="<?php echo e(url('/')); ?>">Go To Back</a>
</body>
</html>
<!-- IE needs 512+ bytes: http://blogs.msdn.com/b/ieinternals/archive/2010/08/19/http-error-pages-in-internet-explorer.aspx -->
<?php /**PATH E:\xampp\htdocs\keyur-test\work\collegeprojects\payrolle_system\website\resources\views/errors/default.blade.php ENDPATH**/ ?>